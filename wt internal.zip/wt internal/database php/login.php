<?php
$conn=mysqli_connect('localhost','root','','test');
if($conn){
    echo "connected";
    $q="insert into apple values ('$_POST[name]','$_POST[password]') ";
    echo "<br>";
    $conn->query($q);
    if($conn){
      echo $_POST['name'];
      echo "<br>";
      echo $_POST['password'];
      echo "<br>";
        echo "inserted successfully";
    }
}

?>