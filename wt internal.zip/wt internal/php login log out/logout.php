<?php
session_start();

// Unset the session variable(s)
unset($_SESSION['username']);

// Destroy the session
session_destroy();

// Redirect to the login page
header('Location: login.html');
exit();
?>
