<?php
session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the submitted username and password
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validate the credentials (You can replace this with your own validation logic)
    if ($username != '' && $password != '') {
        // Authentication successful, create a session variable
        $_SESSION['username'] = $username;

        // Redirect to the home page or any other authorized page
        header('Location: home.php');
        exit();
    } else {
        // Invalid credentials, display an error message
        echo "Invalid username or password.";
    }
}
?>
