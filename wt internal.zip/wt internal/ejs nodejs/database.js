const express=require('express')
const app=express();
const mysql=require('mysql')
const ejs=require('ejs')
app.set('view engine','ejs')
app.use(express.urlencoded({extended:true}))
const conn=mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"test"
})
app.get('/',(req,res)=>{
    conn.query("select * from apple",(err,data)=>{
      if(data.length>0){
        const s=data[0].name
        data.forEach(element => {
          console.log(element)
        });
        res.json({"len":data.length})
      }
    })
})
app.get('/index',(req,res)=>{
  res.render('index')
})
app.post('/form',(req,res)=>{
  const d=req.body
  res.json(d.text)
})
app.listen(3000);