<!DOCTYPE html>
<html>
<head>
    <title>File Upload and Display Image</title>
</head>
<body>
    <h1>File Upload and Display Image</h1>

    <form method="POST" action="" enctype="multipart/form-data">
        <input type="file" name="image">
        <input type="submit" value="Upload">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check if a file is selected
        if (isset($_FILES["image"]) && $_FILES["image"]["error"] == UPLOAD_ERR_OK) {
            $tempName = $_FILES["image"]["tmp_name"];
            $fileName = $_FILES["image"]["name"];
            $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
            $allowedExtensions = array("jpg", "jpeg", "png", "gif");

            // Check if the file extension is allowed
            if (in_array($fileExt, $allowedExtensions)) {
                // Define the upload directory
                $uploadDir = "uploads/";

                // Generate a unique filename to prevent conflicts
                $uniqueFileName = uniqid() . "." . $fileExt;

                // Move the uploaded file to the upload directory
                if (move_uploaded_file($tempName, $uploadDir . $uniqueFileName)) {
                    echo "<p>Image uploaded successfully!</p>";
                    echo '<img src="' . $uploadDir . $uniqueFileName . '" alt="Uploaded Image">';
                } else {
                    echo "<p>Sorry, there was an error uploading the file.</p>";
                }
            } else {
                echo "<p>Invalid file extension. Only JPG, JPEG, PNG, and GIF files are allowed.</p>";
            }
        } else {
            echo "<p>Please select a file to upload.</p>";
        }
    }
    ?>
</body>
</htm