const express = require('express');
const app = express();
const ejs = require('ejs');
const multer = require('multer');
const path = require('path');

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));

// Set up Multer middleware
const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: function (req, file, cb) {
    // Preserve the original filename
    const originalName = file.originalname;
    cb(null, originalName);
  }
});

const upload = multer({ storage: storage });

app.get('/', (req, res) => {
  res.render('index');
});

app.post('/form', upload.single('text'), (req, res) => {
  const file = req.file;
  const filePath = file.path; // Get the path of the uploaded file

  res.send(file)
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});