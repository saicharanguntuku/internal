const express=require('express')
const app=express();
const mysql=require('mysql')
const conn=mysql.createConnection({
  host:"localhost",
  user:"root",
  password:"",
  database:"test"
})
app.get('/',(req,res)=>{
    conn.query("select * from apple",(err,data)=>{
      if(data.length>0){
        const s=data[0].name
        data.forEach(element => {
          console.log(element)
        });
        res.json({"len":data.length})
      }
    })
})
app.listen(3000);